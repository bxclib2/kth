public class Flow2Match {
	
	public static void main(String[] args) {
		
	}
	
		getString();
		getString()
		int edges = parse(getString());
		String s;
		for(int i = 0; i < edges; i++) {
			s = getString();
		}
	
	
	public static int parse(String s) throws NumberFormatException {
		return Integer.parseInt(s);
	}
	
	// Read a String from standard system input
	public static String getString() {
		try {
			return in.readLine();
		} catch( IOException e ) {
			System.out.println("getString() exception, returning empty string");
			return "";
		}
	}
}